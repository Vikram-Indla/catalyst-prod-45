# Required inputs checklist (fill these for Lovable / devs)

## 1) Design tokens (paste into 03_design_tokens_template.json)
- Font family:
- Base font size:
- Heading scale:
- Line heights:
- Border radius scale:
- Neutral colors (backgrounds, borders, text):
- Brand primary color:
- Danger color:
- Success color:
- Status lozenge styles:
- Table row height targets (dense):

## 2) Top nav integration
- Top nav component name/path:
- Where to insert Project Switcher:
- Where to insert Create button:

## 3) Drawer (right-side issue panel) integration
- Existing drawer component name/path (if any):
- Current pattern: drawer or full page (you said drawer): YES
- Width behavior (px or %):
- How it opens (state param / route / context store):

## 4) Data contracts
Provide real JSON samples for:
- Feature
- Story (must include parentFeatureId)
- Task
- Bug/Defect
- Sub-task (must include parentWorkItemId)

## 5) API contracts (or confirm mock)
List endpoints for:
- Projects list
- Work items list by project key
- Work item detail by key
- Update work item fields (PATCH)
- Transition status
- Archive/restore
- Move across projects
- Link/unlink work items
- Comments + @mentions
- Attachments upload
- Worklogs (log work)
- Search (basic + JQL-like)
- Programs + Epics + Epic link (to Feature/Story only)

## 6) Admin deep links (confirm exact routes)
- Board settings:
- Field layout/details panels:
- Linking config:
- Roles/permissions:
- Audit log:
