# Catalyst ⇄ Jira Parity “Download Dump” (v1) — 2025-12-08

This pack is a **fill-in template** you can give to Lovable (UI build) and Claude/devs (full-stack build) to avoid hallucinations.
It is designed to **reuse your existing Catalyst shell and routes** and only add:
1) Top-nav Create button
2) /browse/:key deep-link resolver
3) /search Issue Navigator

## What you need to do
1. Open `02_required_inputs_checklist.md` and fill the blanks.
2. Replace the sample JSON files under `05_data_contract/samples/` with **real examples** from Catalyst (or keep as mocks).
3. Fill `06_api_contract_template.yaml` with your actual endpoints (or keep mock endpoints and stubs).
4. Paste `01_lovable_master_prompt.txt` into Lovable after you fill the placeholders in:
   - `03_design_tokens_template.json`
   - `08_admin_deeplinks.md`

## Output expectation
- Lovable builds UI with **sleek dense lists** and **compact board cards**, Jira-like typography rhythm, Catalyst colors.
- No new project route tree; use your existing pages with `?project=KEY` scoping.

## Folder map
- `01_lovable_master_prompt.txt` → paste into Lovable
- `05_data_contract/` → JSON contract + samples for Feature/Story/Task/Bug/Sub-task
- `06_api_contract_template.yaml` → endpoint list + request/response shapes
- `07_ui_acceptance_criteria.md` → “no big cards” rules & pixel acceptance checks
