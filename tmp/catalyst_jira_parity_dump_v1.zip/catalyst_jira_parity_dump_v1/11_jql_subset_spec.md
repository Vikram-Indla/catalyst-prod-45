# JQL-like subset spec (Phase 1)

Implement a minimal subset to support Jira-style Issue Navigator behaviors.

## Supported terms
- project = KEY
- type in (FEATURE, STORY, TASK, BUG, SUBTASK)
- status in (TODO, IN_PROGRESS, DONE)
- assignee = <userId> or "currentUser()"
- text ~ "keyword"
- ORDER BY updated DESC | rank ASC

## Examples
- project=ABC ORDER BY rank ASC
- project=ABC AND type in (STORY,BUG) AND status != DONE ORDER BY updated DESC
- text ~ "login" AND project=ABC

## Notes
- Treat this as a parsed filter DSL; you do not need full Jira JQL v1.
