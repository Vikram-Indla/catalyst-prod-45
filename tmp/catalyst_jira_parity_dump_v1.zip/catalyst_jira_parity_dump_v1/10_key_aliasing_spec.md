# Key aliasing & /browse resolver spec

## Why
When moving items between projects, keys change (e.g., ABC-1 → XYZ-55).
Old keys must continue to resolve via historical key redirects.

## Behavior
- /browse/:key
  1) Try resolve current key.
  2) If not found, resolve via key alias table.
  3) If found via alias, open current item and show a small banner: "Redirected from OLDKEY".

## Data
- work_item_key_aliases:
  - workItemId
  - oldKey
  - createdAt
- work_items:
  - currentKey

## Edge cases
- Multiple moves: keep multiple aliases; all resolve to currentKey.
- Merge/clone: cloning should NOT inherit aliases.
