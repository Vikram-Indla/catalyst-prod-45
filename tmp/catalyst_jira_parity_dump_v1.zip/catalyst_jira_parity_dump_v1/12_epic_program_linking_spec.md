# Program Epic linking spec (strict)

## Rule
Program Epics can link ONLY to:
- FEATURE
- STORY

They must NEVER link to:
- TASK
- BUG
- SUBTASK

## UI
- In Feature/Story drawer: Program Epic field is editable (picker).
- In Task/Bug/Subtask drawer: Program Epic shows inherited value read-only.

## Validation
- Backend must reject link attempts to non Feature/Story.
- UI must not show non Feature/Story as selectable targets.
