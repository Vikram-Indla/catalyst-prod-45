# Route reuse map (Catalyst routes → Jira-like workspace)

## Do NOT create /projects/:key/*
Project context is applied via query param: ?project=KEY

### Project-scoped core pages
- Backlog (Scrum): /backlog?project=KEY
- Sprints list: /sprints?project=KEY
- Sprint board: /sprint-board?project=KEY
- Releases/Versions: /releases?project=KEY (or /release/versions?project=KEY depending on your existing implementation)
- Issue Navigator: /search?jql=project=KEY ORDER BY Rank

### Required new routes (approved)
- /browse/:key  (deep-link resolver that opens issue panel by key)
- /search        (global Issue Navigator)

### URL state (issue panel open-on-top)
- /backlog?project=ABC&selected=ABC-123
- /sprint-board?project=ABC&selected=ABC-123
- /search?jql=project=ABC&selected=ABC-123
