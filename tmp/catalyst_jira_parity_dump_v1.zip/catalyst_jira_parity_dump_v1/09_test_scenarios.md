# Manual QA scenarios (Jira parity)

## Create
1) Create project (Scrum) → ensure backlog loads via /backlog?project=KEY
2) Create Feature in project → visible in list/board/backlog
3) Create Story → must require selecting Parent Feature
4) Create Bug → allow Sub-task creation under it
5) Create Sub-task → must require parent (Story/Task/Bug)

## Edit
6) Inline edit Summary in list
7) Change Status on board via drag/drop
8) Edit time tracking + log work; verify totals update

## Link / Clone / Archive
9) Link item + create linked item from same modal
10) Clone item; verify fields copied appropriately
11) Archive item; verify read-only + hidden from default lists
12) Restore item; if subtask restore requires parent restored

## Move + Historical keys
13) Move ABC-123 to project XYZ → becomes XYZ-###
14) /browse/ABC-123 redirects to current item and shows “Redirected from ABC-123” banner

## Search
15) /search basic query returns table rows
16) /search advanced JQL-like query filters by project/type/status
17) Bulk select rows → bulk move / bulk transition / bulk archive available

## Program Epics
18) Create epic in program; link epic to Feature and Story only
19) Ensure linking modal never shows Task/Bug/Sub-task as selectable targets
