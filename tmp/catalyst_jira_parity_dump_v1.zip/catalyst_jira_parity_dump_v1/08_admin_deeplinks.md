# Admin deep links (confirm these route targets)

Use these existing routes; DO NOT create new settings pages.
- Board settings: /admin/boards  (or /admin/jira-config if that's where you configure columns/statuses)
- Field layout (details panels): /admin/details-panels
- Linking config: /admin/jira-config
- Roles & permissions: /admin/roles-permissions
- Audit log: /admin/activity-log  (or /admin/changes-log depending on your implementation)
