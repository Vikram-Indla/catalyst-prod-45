# UI acceptance criteria (sleek Jira-like density)

## Global
- No "big cards" for lists or dashboards.
- Dense tables, minimal padding, subtle dividers.
- Atlassian-like typography rhythm; Catalyst colors only as semantic mapping.

## Board cards
- Max 2-line summary (truncate).
- Shows: KEY + Summary + Status lozenge + Assignee avatar.
- Optional: 1 extra field (default off or single field).

## Issue drawer/panel
- Compact header (no oversized title area).
- Details tab uses compact two-column grid.
- Activity tab uses slim list items for comments/worklogs.

## Tables (Issue Navigator / List view)
- Row height: dense
- Sticky header
- Inline edit for summary/status/assignee/priority
- Bulk action bar appears only when rows selected

## Prohibited
- Large “card” containers around tables.
- Oversized empty states.
- Wide padding (>=24px) on dense views.
